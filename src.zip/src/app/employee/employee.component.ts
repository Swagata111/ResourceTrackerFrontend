import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  model: EmployeePojo = {
    employeeId: null,
    employeeName: '',
    localGrade: '',
    grade: '',
    mode: '',
    cloudJoiningDate: '',
    joiningDate: '',
    officeLocation: '',
    location: '',
    seat: '',
    email: '',
    benchStartDate: '',
    level3EngagementRole: '',
    gP: '',
    currentAccount: '',
    projectCode: '',
    projectName: '',
    projectStartDate: '',
    projectEndDate: '',
    primarySkill: ''
  };

  

  constructor(private http:HttpClient) { }

  ngOnInit() {
  }

  create(): void 
  {
     let url="http://localhost:9090/create";
     this.http.post(url,this.model).subscribe();
     alert('You have successfully inserted data!');
     location.href= 'http://localhost:4200';
  }
}


export interface EmployeePojo 
{
  employeeId: number,
    employeeName: string,
    localGrade: string,
    grade: string,
    mode: string,
    cloudJoiningDate: string,
    joiningDate: string,
    officeLocation: string,
    location: string,
    seat: string,
    email: string,
    benchStartDate: string,
    level3EngagementRole: string,
    gP: string,
    currentAccount: string,
    projectCode: string,
    projectName: string,
    projectStartDate: string,
    projectEndDate: string,
    primarySkill: string
}


